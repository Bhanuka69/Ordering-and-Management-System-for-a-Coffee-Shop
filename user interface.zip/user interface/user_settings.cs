﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace user_interface
{
    public partial class user_settings : Form
    {
        public user_settings()
        {
            InitializeComponent();
        }

        private void Edit_Click(object sender, EventArgs e)
        {

        }

        private void user_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Firstname_Click(object sender, EventArgs e)
        {

        }

        private void txt_totalprice_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
