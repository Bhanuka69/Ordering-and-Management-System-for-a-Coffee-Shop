﻿
namespace user_interface
{
    partial class savouries
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(savouries));
            this.savouriespanel = new System.Windows.Forms.FlowLayoutPanel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label17 = new System.Windows.Forms.Label();
            this.guna2GradientButton5 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2Separator3 = new Guna.UI2.WinForms.Guna2Separator();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.guna2GradientButton4 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientButton3 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.Cappuccino_panel = new System.Windows.Forms.Panel();
            this.tital_panal_cappuccino = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.label14 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.guna2GradientButton6 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2Separator4 = new Guna.UI2.WinForms.Guna2Separator();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.guna2GradientButton7 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientButton8 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.panel7 = new System.Windows.Forms.Panel();
            this.guna2CustomGradientPanel2 = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label25 = new System.Windows.Forms.Label();
            this.guna2GradientButton9 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2Separator5 = new Guna.UI2.WinForms.Guna2Separator();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.guna2GradientButton10 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientButton11 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.panel9 = new System.Windows.Forms.Panel();
            this.guna2CustomGradientPanel3 = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label33 = new System.Windows.Forms.Label();
            this.guna2GradientButton12 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2Separator6 = new Guna.UI2.WinForms.Guna2Separator();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.guna2GradientButton13 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientButton14 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.panel11 = new System.Windows.Forms.Panel();
            this.guna2CustomGradientPanel4 = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.panel12 = new System.Windows.Forms.Panel();
            this.label41 = new System.Windows.Forms.Label();
            this.guna2GradientButton15 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2Separator7 = new Guna.UI2.WinForms.Guna2Separator();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.guna2GradientButton16 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientButton17 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.panel13 = new System.Windows.Forms.Panel();
            this.guna2CustomGradientPanel5 = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.panel16 = new System.Windows.Forms.Panel();
            this.label57 = new System.Windows.Forms.Label();
            this.guna2GradientButton21 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2Separator9 = new Guna.UI2.WinForms.Guna2Separator();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.guna2GradientButton22 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientButton23 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.panel17 = new System.Windows.Forms.Panel();
            this.guna2CustomGradientPanel7 = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.panel14 = new System.Windows.Forms.Panel();
            this.label49 = new System.Windows.Forms.Label();
            this.guna2GradientButton18 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2Separator8 = new Guna.UI2.WinForms.Guna2Separator();
            this.label51 = new System.Windows.Forms.Label();
            this.guna2GradientButton19 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientButton20 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.panel15 = new System.Windows.Forms.Panel();
            this.guna2CustomGradientPanel6 = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.savouriespanel.SuspendLayout();
            this.panel4.SuspendLayout();
            this.Cappuccino_panel.SuspendLayout();
            this.tital_panal_cappuccino.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.guna2CustomGradientPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.guna2CustomGradientPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.panel10.SuspendLayout();
            this.panel11.SuspendLayout();
            this.guna2CustomGradientPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            this.panel12.SuspendLayout();
            this.panel13.SuspendLayout();
            this.guna2CustomGradientPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            this.panel16.SuspendLayout();
            this.panel17.SuspendLayout();
            this.guna2CustomGradientPanel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            this.panel14.SuspendLayout();
            this.panel15.SuspendLayout();
            this.guna2CustomGradientPanel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            this.SuspendLayout();
            // 
            // savouriespanel
            // 
            this.savouriespanel.AutoScroll = true;
            this.savouriespanel.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.savouriespanel.Controls.Add(this.panel4);
            this.savouriespanel.Controls.Add(this.panel6);
            this.savouriespanel.Controls.Add(this.panel8);
            this.savouriespanel.Controls.Add(this.panel10);
            this.savouriespanel.Controls.Add(this.panel12);
            this.savouriespanel.Controls.Add(this.panel16);
            this.savouriespanel.Controls.Add(this.panel14);
            this.savouriespanel.Controls.Add(this.label50);
            this.savouriespanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.savouriespanel.Location = new System.Drawing.Point(0, 0);
            this.savouriespanel.Name = "savouriespanel";
            this.savouriespanel.Size = new System.Drawing.Size(800, 450);
            this.savouriespanel.TabIndex = 16;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.label17);
            this.panel4.Controls.Add(this.guna2GradientButton5);
            this.panel4.Controls.Add(this.guna2Separator3);
            this.panel4.Controls.Add(this.label15);
            this.panel4.Controls.Add(this.label16);
            this.panel4.Controls.Add(this.guna2GradientButton4);
            this.panel4.Controls.Add(this.guna2GradientButton3);
            this.panel4.Controls.Add(this.Cappuccino_panel);
            this.panel4.Location = new System.Drawing.Point(3, 3);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(334, 546);
            this.panel4.TabIndex = 0;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(46, 503);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(52, 19);
            this.label17.TabIndex = 22;
            this.label17.Text = "Rs 200";
            // 
            // guna2GradientButton5
            // 
            this.guna2GradientButton5.Animated = true;
            this.guna2GradientButton5.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton5.CheckedState.Parent = this.guna2GradientButton5;
            this.guna2GradientButton5.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("guna2GradientButton5.CustomImages.Image")));
            this.guna2GradientButton5.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2GradientButton5.CustomImages.Parent = this.guna2GradientButton5;
            this.guna2GradientButton5.FillColor = System.Drawing.Color.Empty;
            this.guna2GradientButton5.FillColor2 = System.Drawing.Color.Empty;
            this.guna2GradientButton5.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton5.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton5.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.guna2GradientButton5.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.guna2GradientButton5.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton5.HoverState.Parent = this.guna2GradientButton5;
            this.guna2GradientButton5.Location = new System.Drawing.Point(154, 470);
            this.guna2GradientButton5.Name = "guna2GradientButton5";
            this.guna2GradientButton5.ShadowDecoration.Parent = this.guna2GradientButton5;
            this.guna2GradientButton5.Size = new System.Drawing.Size(141, 52);
            this.guna2GradientButton5.TabIndex = 21;
            this.guna2GradientButton5.Text = "Medium";
            this.guna2GradientButton5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.guna2GradientButton5.TextOffset = new System.Drawing.Point(10, 0);
            this.guna2GradientButton5.UseTransparentBackground = true;
            // 
            // guna2Separator3
            // 
            this.guna2Separator3.Location = new System.Drawing.Point(26, 454);
            this.guna2Separator3.Name = "guna2Separator3";
            this.guna2Separator3.Size = new System.Drawing.Size(286, 10);
            this.guna2Separator3.TabIndex = 20;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(32, 461);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(81, 37);
            this.label15.TabIndex = 19;
            this.label15.Text = "Price";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(47, 417);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(28, 15);
            this.label16.TabIndex = 18;
            this.label16.Text = "size";
            // 
            // guna2GradientButton4
            // 
            this.guna2GradientButton4.Animated = true;
            this.guna2GradientButton4.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton4.CheckedState.Parent = this.guna2GradientButton4;
            this.guna2GradientButton4.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("guna2GradientButton4.CustomImages.Image")));
            this.guna2GradientButton4.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2GradientButton4.CustomImages.Parent = this.guna2GradientButton4;
            this.guna2GradientButton4.FillColor = System.Drawing.Color.Empty;
            this.guna2GradientButton4.FillColor2 = System.Drawing.Color.Empty;
            this.guna2GradientButton4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton4.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton4.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.guna2GradientButton4.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.guna2GradientButton4.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton4.HoverState.Parent = this.guna2GradientButton4;
            this.guna2GradientButton4.Location = new System.Drawing.Point(135, 403);
            this.guna2GradientButton4.Name = "guna2GradientButton4";
            this.guna2GradientButton4.ShadowDecoration.Parent = this.guna2GradientButton4;
            this.guna2GradientButton4.Size = new System.Drawing.Size(86, 45);
            this.guna2GradientButton4.TabIndex = 17;
            this.guna2GradientButton4.Text = "Medium";
            this.guna2GradientButton4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.guna2GradientButton4.TextOffset = new System.Drawing.Point(10, 0);
            this.guna2GradientButton4.UseTransparentBackground = true;
            // 
            // guna2GradientButton3
            // 
            this.guna2GradientButton3.Animated = true;
            this.guna2GradientButton3.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton3.CheckedState.Parent = this.guna2GradientButton3;
            this.guna2GradientButton3.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("guna2GradientButton3.CustomImages.Image")));
            this.guna2GradientButton3.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2GradientButton3.CustomImages.Parent = this.guna2GradientButton3;
            this.guna2GradientButton3.FillColor = System.Drawing.Color.Empty;
            this.guna2GradientButton3.FillColor2 = System.Drawing.Color.Empty;
            this.guna2GradientButton3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton3.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton3.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.guna2GradientButton3.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.guna2GradientButton3.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton3.HoverState.Parent = this.guna2GradientButton3;
            this.guna2GradientButton3.Location = new System.Drawing.Point(222, 403);
            this.guna2GradientButton3.Name = "guna2GradientButton3";
            this.guna2GradientButton3.ShadowDecoration.Parent = this.guna2GradientButton3;
            this.guna2GradientButton3.Size = new System.Drawing.Size(105, 45);
            this.guna2GradientButton3.TabIndex = 16;
            this.guna2GradientButton3.Text = "Large";
            this.guna2GradientButton3.UseTransparentBackground = true;
            // 
            // Cappuccino_panel
            // 
            this.Cappuccino_panel.BackgroundImage = global::user_interface.Properties.Resources.istockphoto_173245886_612x612;
            this.Cappuccino_panel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Cappuccino_panel.Controls.Add(this.tital_panal_cappuccino);
            this.Cappuccino_panel.Location = new System.Drawing.Point(15, 12);
            this.Cappuccino_panel.Name = "Cappuccino_panel";
            this.Cappuccino_panel.Size = new System.Drawing.Size(300, 358);
            this.Cappuccino_panel.TabIndex = 0;
            // 
            // tital_panal_cappuccino
            // 
            this.tital_panal_cappuccino.BackColor = System.Drawing.Color.Transparent;
            this.tital_panal_cappuccino.Controls.Add(this.label14);
            this.tital_panal_cappuccino.Controls.Add(this.label12);
            this.tital_panal_cappuccino.Controls.Add(this.label13);
            this.tital_panal_cappuccino.Controls.Add(this.pictureBox2);
            this.tital_panal_cappuccino.Controls.Add(this.pictureBox1);
            this.tital_panal_cappuccino.Controls.Add(this.label11);
            this.tital_panal_cappuccino.Controls.Add(this.label10);
            this.tital_panal_cappuccino.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tital_panal_cappuccino.FillColor = System.Drawing.Color.Transparent;
            this.tital_panal_cappuccino.FillColor2 = System.Drawing.Color.Transparent;
            this.tital_panal_cappuccino.FillColor3 = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.tital_panal_cappuccino.FillColor4 = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(140)))), ((int)(((byte)(52)))));
            this.tital_panal_cappuccino.Location = new System.Drawing.Point(0, 252);
            this.tital_panal_cappuccino.Name = "tital_panal_cappuccino";
            this.tital_panal_cappuccino.ShadowDecoration.Parent = this.tital_panal_cappuccino;
            this.tital_panal_cappuccino.Size = new System.Drawing.Size(300, 106);
            this.tital_panal_cappuccino.TabIndex = 9;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(192, 87);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(101, 15);
            this.label14.TabIndex = 22;
            this.label14.Text = "Medium Roasted";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(204, 72);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(44, 15);
            this.label12.TabIndex = 19;
            this.label12.Text = "coffee";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(258, 72);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(31, 15);
            this.label13.TabIndex = 20;
            this.label13.Text = "milk";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(249, 18);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(48, 48);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox2.TabIndex = 21;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(195, 18);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 48);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            // 
            // label11
            // 
            this.label11.Font = new System.Drawing.Font("Segoe UI", 15F);
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(19, 58);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(139, 29);
            this.label11.TabIndex = 20;
            this.label11.Text = "With Oat Milk";
            // 
            // label10
            // 
            this.label10.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(19, 18);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(184, 40);
            this.label10.TabIndex = 19;
            this.label10.Text = "Cappuccino";
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.label8);
            this.panel6.Controls.Add(this.guna2GradientButton6);
            this.panel6.Controls.Add(this.guna2Separator4);
            this.panel6.Controls.Add(this.label18);
            this.panel6.Controls.Add(this.label19);
            this.panel6.Controls.Add(this.guna2GradientButton7);
            this.panel6.Controls.Add(this.guna2GradientButton8);
            this.panel6.Controls.Add(this.panel7);
            this.panel6.Location = new System.Drawing.Point(343, 3);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(334, 546);
            this.panel6.TabIndex = 23;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(46, 503);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(52, 19);
            this.label8.TabIndex = 22;
            this.label8.Text = "Rs 200";
            // 
            // guna2GradientButton6
            // 
            this.guna2GradientButton6.Animated = true;
            this.guna2GradientButton6.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton6.CheckedState.Parent = this.guna2GradientButton6;
            this.guna2GradientButton6.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("guna2GradientButton6.CustomImages.Image")));
            this.guna2GradientButton6.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2GradientButton6.CustomImages.Parent = this.guna2GradientButton6;
            this.guna2GradientButton6.FillColor = System.Drawing.Color.Empty;
            this.guna2GradientButton6.FillColor2 = System.Drawing.Color.Empty;
            this.guna2GradientButton6.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton6.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton6.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.guna2GradientButton6.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.guna2GradientButton6.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton6.HoverState.Parent = this.guna2GradientButton6;
            this.guna2GradientButton6.Location = new System.Drawing.Point(154, 470);
            this.guna2GradientButton6.Name = "guna2GradientButton6";
            this.guna2GradientButton6.ShadowDecoration.Parent = this.guna2GradientButton6;
            this.guna2GradientButton6.Size = new System.Drawing.Size(141, 52);
            this.guna2GradientButton6.TabIndex = 21;
            this.guna2GradientButton6.Text = "Medium";
            this.guna2GradientButton6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.guna2GradientButton6.TextOffset = new System.Drawing.Point(10, 0);
            this.guna2GradientButton6.UseTransparentBackground = true;
            // 
            // guna2Separator4
            // 
            this.guna2Separator4.Location = new System.Drawing.Point(26, 454);
            this.guna2Separator4.Name = "guna2Separator4";
            this.guna2Separator4.Size = new System.Drawing.Size(286, 10);
            this.guna2Separator4.TabIndex = 20;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(32, 461);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(81, 37);
            this.label18.TabIndex = 19;
            this.label18.Text = "Price";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(47, 417);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(28, 15);
            this.label19.TabIndex = 18;
            this.label19.Text = "size";
            // 
            // guna2GradientButton7
            // 
            this.guna2GradientButton7.Animated = true;
            this.guna2GradientButton7.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton7.CheckedState.Parent = this.guna2GradientButton7;
            this.guna2GradientButton7.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("guna2GradientButton7.CustomImages.Image")));
            this.guna2GradientButton7.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2GradientButton7.CustomImages.Parent = this.guna2GradientButton7;
            this.guna2GradientButton7.FillColor = System.Drawing.Color.Empty;
            this.guna2GradientButton7.FillColor2 = System.Drawing.Color.Empty;
            this.guna2GradientButton7.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton7.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton7.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.guna2GradientButton7.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.guna2GradientButton7.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton7.HoverState.Parent = this.guna2GradientButton7;
            this.guna2GradientButton7.Location = new System.Drawing.Point(135, 403);
            this.guna2GradientButton7.Name = "guna2GradientButton7";
            this.guna2GradientButton7.ShadowDecoration.Parent = this.guna2GradientButton7;
            this.guna2GradientButton7.Size = new System.Drawing.Size(86, 45);
            this.guna2GradientButton7.TabIndex = 17;
            this.guna2GradientButton7.Text = "Medium";
            this.guna2GradientButton7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.guna2GradientButton7.TextOffset = new System.Drawing.Point(10, 0);
            this.guna2GradientButton7.UseTransparentBackground = true;
            // 
            // guna2GradientButton8
            // 
            this.guna2GradientButton8.Animated = true;
            this.guna2GradientButton8.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton8.CheckedState.Parent = this.guna2GradientButton8;
            this.guna2GradientButton8.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("guna2GradientButton8.CustomImages.Image")));
            this.guna2GradientButton8.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2GradientButton8.CustomImages.Parent = this.guna2GradientButton8;
            this.guna2GradientButton8.FillColor = System.Drawing.Color.Empty;
            this.guna2GradientButton8.FillColor2 = System.Drawing.Color.Empty;
            this.guna2GradientButton8.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton8.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton8.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.guna2GradientButton8.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.guna2GradientButton8.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton8.HoverState.Parent = this.guna2GradientButton8;
            this.guna2GradientButton8.Location = new System.Drawing.Point(222, 403);
            this.guna2GradientButton8.Name = "guna2GradientButton8";
            this.guna2GradientButton8.ShadowDecoration.Parent = this.guna2GradientButton8;
            this.guna2GradientButton8.Size = new System.Drawing.Size(105, 45);
            this.guna2GradientButton8.TabIndex = 16;
            this.guna2GradientButton8.Text = "Large";
            this.guna2GradientButton8.UseTransparentBackground = true;
            // 
            // panel7
            // 
            this.panel7.BackgroundImage = global::user_interface.Properties.Resources.istockphoto_173245886_612x612;
            this.panel7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.panel7.Controls.Add(this.guna2CustomGradientPanel2);
            this.panel7.Location = new System.Drawing.Point(15, 12);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(300, 358);
            this.panel7.TabIndex = 0;
            // 
            // guna2CustomGradientPanel2
            // 
            this.guna2CustomGradientPanel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2CustomGradientPanel2.Controls.Add(this.label20);
            this.guna2CustomGradientPanel2.Controls.Add(this.label21);
            this.guna2CustomGradientPanel2.Controls.Add(this.label22);
            this.guna2CustomGradientPanel2.Controls.Add(this.pictureBox3);
            this.guna2CustomGradientPanel2.Controls.Add(this.pictureBox4);
            this.guna2CustomGradientPanel2.Controls.Add(this.label23);
            this.guna2CustomGradientPanel2.Controls.Add(this.label24);
            this.guna2CustomGradientPanel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.guna2CustomGradientPanel2.FillColor = System.Drawing.Color.Transparent;
            this.guna2CustomGradientPanel2.FillColor2 = System.Drawing.Color.Transparent;
            this.guna2CustomGradientPanel2.FillColor3 = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.guna2CustomGradientPanel2.FillColor4 = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(140)))), ((int)(((byte)(52)))));
            this.guna2CustomGradientPanel2.Location = new System.Drawing.Point(0, 252);
            this.guna2CustomGradientPanel2.Name = "guna2CustomGradientPanel2";
            this.guna2CustomGradientPanel2.ShadowDecoration.Parent = this.guna2CustomGradientPanel2;
            this.guna2CustomGradientPanel2.Size = new System.Drawing.Size(300, 106);
            this.guna2CustomGradientPanel2.TabIndex = 9;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label20.ForeColor = System.Drawing.Color.White;
            this.label20.Location = new System.Drawing.Point(192, 87);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(101, 15);
            this.label20.TabIndex = 22;
            this.label20.Text = "Medium Roasted";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label21.ForeColor = System.Drawing.Color.White;
            this.label21.Location = new System.Drawing.Point(204, 72);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(44, 15);
            this.label21.TabIndex = 19;
            this.label21.Text = "coffee";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label22.ForeColor = System.Drawing.Color.White;
            this.label22.Location = new System.Drawing.Point(258, 72);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(31, 15);
            this.label22.TabIndex = 20;
            this.label22.Text = "milk";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(249, 18);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(48, 48);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox3.TabIndex = 21;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(195, 18);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(48, 48);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox4.TabIndex = 10;
            this.pictureBox4.TabStop = false;
            // 
            // label23
            // 
            this.label23.Font = new System.Drawing.Font("Segoe UI", 15F);
            this.label23.ForeColor = System.Drawing.Color.White;
            this.label23.Location = new System.Drawing.Point(19, 58);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(139, 29);
            this.label23.TabIndex = 20;
            this.label23.Text = "With Oat Milk";
            // 
            // label24
            // 
            this.label24.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.label24.ForeColor = System.Drawing.Color.White;
            this.label24.Location = new System.Drawing.Point(19, 18);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(184, 40);
            this.label24.TabIndex = 19;
            this.label24.Text = "Cappuccino";
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.label25);
            this.panel8.Controls.Add(this.guna2GradientButton9);
            this.panel8.Controls.Add(this.guna2Separator5);
            this.panel8.Controls.Add(this.label26);
            this.panel8.Controls.Add(this.label27);
            this.panel8.Controls.Add(this.guna2GradientButton10);
            this.panel8.Controls.Add(this.guna2GradientButton11);
            this.panel8.Controls.Add(this.panel9);
            this.panel8.Location = new System.Drawing.Point(3, 555);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(334, 546);
            this.panel8.TabIndex = 24;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.label25.ForeColor = System.Drawing.Color.White;
            this.label25.Location = new System.Drawing.Point(46, 503);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(52, 19);
            this.label25.TabIndex = 22;
            this.label25.Text = "Rs 200";
            // 
            // guna2GradientButton9
            // 
            this.guna2GradientButton9.Animated = true;
            this.guna2GradientButton9.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton9.CheckedState.Parent = this.guna2GradientButton9;
            this.guna2GradientButton9.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("guna2GradientButton9.CustomImages.Image")));
            this.guna2GradientButton9.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2GradientButton9.CustomImages.Parent = this.guna2GradientButton9;
            this.guna2GradientButton9.FillColor = System.Drawing.Color.Empty;
            this.guna2GradientButton9.FillColor2 = System.Drawing.Color.Empty;
            this.guna2GradientButton9.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton9.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton9.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.guna2GradientButton9.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.guna2GradientButton9.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton9.HoverState.Parent = this.guna2GradientButton9;
            this.guna2GradientButton9.Location = new System.Drawing.Point(154, 470);
            this.guna2GradientButton9.Name = "guna2GradientButton9";
            this.guna2GradientButton9.ShadowDecoration.Parent = this.guna2GradientButton9;
            this.guna2GradientButton9.Size = new System.Drawing.Size(141, 52);
            this.guna2GradientButton9.TabIndex = 21;
            this.guna2GradientButton9.Text = "Medium";
            this.guna2GradientButton9.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.guna2GradientButton9.TextOffset = new System.Drawing.Point(10, 0);
            this.guna2GradientButton9.UseTransparentBackground = true;
            // 
            // guna2Separator5
            // 
            this.guna2Separator5.Location = new System.Drawing.Point(26, 454);
            this.guna2Separator5.Name = "guna2Separator5";
            this.guna2Separator5.Size = new System.Drawing.Size(286, 10);
            this.guna2Separator5.TabIndex = 20;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.label26.ForeColor = System.Drawing.Color.White;
            this.label26.Location = new System.Drawing.Point(32, 461);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(81, 37);
            this.label26.TabIndex = 19;
            this.label26.Text = "Price";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label27.ForeColor = System.Drawing.Color.White;
            this.label27.Location = new System.Drawing.Point(47, 417);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(28, 15);
            this.label27.TabIndex = 18;
            this.label27.Text = "size";
            // 
            // guna2GradientButton10
            // 
            this.guna2GradientButton10.Animated = true;
            this.guna2GradientButton10.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton10.CheckedState.Parent = this.guna2GradientButton10;
            this.guna2GradientButton10.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("guna2GradientButton10.CustomImages.Image")));
            this.guna2GradientButton10.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2GradientButton10.CustomImages.Parent = this.guna2GradientButton10;
            this.guna2GradientButton10.FillColor = System.Drawing.Color.Empty;
            this.guna2GradientButton10.FillColor2 = System.Drawing.Color.Empty;
            this.guna2GradientButton10.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton10.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton10.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.guna2GradientButton10.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.guna2GradientButton10.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton10.HoverState.Parent = this.guna2GradientButton10;
            this.guna2GradientButton10.Location = new System.Drawing.Point(135, 403);
            this.guna2GradientButton10.Name = "guna2GradientButton10";
            this.guna2GradientButton10.ShadowDecoration.Parent = this.guna2GradientButton10;
            this.guna2GradientButton10.Size = new System.Drawing.Size(86, 45);
            this.guna2GradientButton10.TabIndex = 17;
            this.guna2GradientButton10.Text = "Medium";
            this.guna2GradientButton10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.guna2GradientButton10.TextOffset = new System.Drawing.Point(10, 0);
            this.guna2GradientButton10.UseTransparentBackground = true;
            // 
            // guna2GradientButton11
            // 
            this.guna2GradientButton11.Animated = true;
            this.guna2GradientButton11.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton11.CheckedState.Parent = this.guna2GradientButton11;
            this.guna2GradientButton11.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("guna2GradientButton11.CustomImages.Image")));
            this.guna2GradientButton11.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2GradientButton11.CustomImages.Parent = this.guna2GradientButton11;
            this.guna2GradientButton11.FillColor = System.Drawing.Color.Empty;
            this.guna2GradientButton11.FillColor2 = System.Drawing.Color.Empty;
            this.guna2GradientButton11.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton11.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton11.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.guna2GradientButton11.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.guna2GradientButton11.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton11.HoverState.Parent = this.guna2GradientButton11;
            this.guna2GradientButton11.Location = new System.Drawing.Point(222, 403);
            this.guna2GradientButton11.Name = "guna2GradientButton11";
            this.guna2GradientButton11.ShadowDecoration.Parent = this.guna2GradientButton11;
            this.guna2GradientButton11.Size = new System.Drawing.Size(105, 45);
            this.guna2GradientButton11.TabIndex = 16;
            this.guna2GradientButton11.Text = "Large";
            this.guna2GradientButton11.UseTransparentBackground = true;
            // 
            // panel9
            // 
            this.panel9.BackgroundImage = global::user_interface.Properties.Resources.istockphoto_173245886_612x612;
            this.panel9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.panel9.Controls.Add(this.guna2CustomGradientPanel3);
            this.panel9.Location = new System.Drawing.Point(15, 12);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(300, 358);
            this.panel9.TabIndex = 0;
            // 
            // guna2CustomGradientPanel3
            // 
            this.guna2CustomGradientPanel3.BackColor = System.Drawing.Color.Transparent;
            this.guna2CustomGradientPanel3.Controls.Add(this.label28);
            this.guna2CustomGradientPanel3.Controls.Add(this.label29);
            this.guna2CustomGradientPanel3.Controls.Add(this.label30);
            this.guna2CustomGradientPanel3.Controls.Add(this.pictureBox5);
            this.guna2CustomGradientPanel3.Controls.Add(this.pictureBox6);
            this.guna2CustomGradientPanel3.Controls.Add(this.label31);
            this.guna2CustomGradientPanel3.Controls.Add(this.label32);
            this.guna2CustomGradientPanel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.guna2CustomGradientPanel3.FillColor = System.Drawing.Color.Transparent;
            this.guna2CustomGradientPanel3.FillColor2 = System.Drawing.Color.Transparent;
            this.guna2CustomGradientPanel3.FillColor3 = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.guna2CustomGradientPanel3.FillColor4 = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(140)))), ((int)(((byte)(52)))));
            this.guna2CustomGradientPanel3.Location = new System.Drawing.Point(0, 252);
            this.guna2CustomGradientPanel3.Name = "guna2CustomGradientPanel3";
            this.guna2CustomGradientPanel3.ShadowDecoration.Parent = this.guna2CustomGradientPanel3;
            this.guna2CustomGradientPanel3.Size = new System.Drawing.Size(300, 106);
            this.guna2CustomGradientPanel3.TabIndex = 9;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label28.ForeColor = System.Drawing.Color.White;
            this.label28.Location = new System.Drawing.Point(192, 87);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(101, 15);
            this.label28.TabIndex = 22;
            this.label28.Text = "Medium Roasted";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label29.ForeColor = System.Drawing.Color.White;
            this.label29.Location = new System.Drawing.Point(204, 72);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(44, 15);
            this.label29.TabIndex = 19;
            this.label29.Text = "coffee";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label30.ForeColor = System.Drawing.Color.White;
            this.label30.Location = new System.Drawing.Point(258, 72);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(31, 15);
            this.label30.TabIndex = 20;
            this.label30.Text = "milk";
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(249, 18);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(48, 48);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox5.TabIndex = 21;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(195, 18);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(48, 48);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox6.TabIndex = 10;
            this.pictureBox6.TabStop = false;
            // 
            // label31
            // 
            this.label31.Font = new System.Drawing.Font("Segoe UI", 15F);
            this.label31.ForeColor = System.Drawing.Color.White;
            this.label31.Location = new System.Drawing.Point(19, 58);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(139, 29);
            this.label31.TabIndex = 20;
            this.label31.Text = "With Oat Milk";
            // 
            // label32
            // 
            this.label32.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.label32.ForeColor = System.Drawing.Color.White;
            this.label32.Location = new System.Drawing.Point(19, 18);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(184, 40);
            this.label32.TabIndex = 19;
            this.label32.Text = "Cappuccino";
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.label33);
            this.panel10.Controls.Add(this.guna2GradientButton12);
            this.panel10.Controls.Add(this.guna2Separator6);
            this.panel10.Controls.Add(this.label34);
            this.panel10.Controls.Add(this.label35);
            this.panel10.Controls.Add(this.guna2GradientButton13);
            this.panel10.Controls.Add(this.guna2GradientButton14);
            this.panel10.Controls.Add(this.panel11);
            this.panel10.Location = new System.Drawing.Point(343, 555);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(334, 546);
            this.panel10.TabIndex = 25;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.label33.ForeColor = System.Drawing.Color.White;
            this.label33.Location = new System.Drawing.Point(46, 503);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(52, 19);
            this.label33.TabIndex = 22;
            this.label33.Text = "Rs 200";
            // 
            // guna2GradientButton12
            // 
            this.guna2GradientButton12.Animated = true;
            this.guna2GradientButton12.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton12.CheckedState.Parent = this.guna2GradientButton12;
            this.guna2GradientButton12.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("guna2GradientButton12.CustomImages.Image")));
            this.guna2GradientButton12.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2GradientButton12.CustomImages.Parent = this.guna2GradientButton12;
            this.guna2GradientButton12.FillColor = System.Drawing.Color.Empty;
            this.guna2GradientButton12.FillColor2 = System.Drawing.Color.Empty;
            this.guna2GradientButton12.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton12.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton12.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.guna2GradientButton12.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.guna2GradientButton12.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton12.HoverState.Parent = this.guna2GradientButton12;
            this.guna2GradientButton12.Location = new System.Drawing.Point(154, 470);
            this.guna2GradientButton12.Name = "guna2GradientButton12";
            this.guna2GradientButton12.ShadowDecoration.Parent = this.guna2GradientButton12;
            this.guna2GradientButton12.Size = new System.Drawing.Size(141, 52);
            this.guna2GradientButton12.TabIndex = 21;
            this.guna2GradientButton12.Text = "Medium";
            this.guna2GradientButton12.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.guna2GradientButton12.TextOffset = new System.Drawing.Point(10, 0);
            this.guna2GradientButton12.UseTransparentBackground = true;
            // 
            // guna2Separator6
            // 
            this.guna2Separator6.Location = new System.Drawing.Point(26, 454);
            this.guna2Separator6.Name = "guna2Separator6";
            this.guna2Separator6.Size = new System.Drawing.Size(286, 10);
            this.guna2Separator6.TabIndex = 20;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.label34.ForeColor = System.Drawing.Color.White;
            this.label34.Location = new System.Drawing.Point(32, 461);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(81, 37);
            this.label34.TabIndex = 19;
            this.label34.Text = "Price";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label35.ForeColor = System.Drawing.Color.White;
            this.label35.Location = new System.Drawing.Point(47, 417);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(28, 15);
            this.label35.TabIndex = 18;
            this.label35.Text = "size";
            // 
            // guna2GradientButton13
            // 
            this.guna2GradientButton13.Animated = true;
            this.guna2GradientButton13.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton13.CheckedState.Parent = this.guna2GradientButton13;
            this.guna2GradientButton13.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("guna2GradientButton13.CustomImages.Image")));
            this.guna2GradientButton13.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2GradientButton13.CustomImages.Parent = this.guna2GradientButton13;
            this.guna2GradientButton13.FillColor = System.Drawing.Color.Empty;
            this.guna2GradientButton13.FillColor2 = System.Drawing.Color.Empty;
            this.guna2GradientButton13.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton13.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton13.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.guna2GradientButton13.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.guna2GradientButton13.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton13.HoverState.Parent = this.guna2GradientButton13;
            this.guna2GradientButton13.Location = new System.Drawing.Point(135, 403);
            this.guna2GradientButton13.Name = "guna2GradientButton13";
            this.guna2GradientButton13.ShadowDecoration.Parent = this.guna2GradientButton13;
            this.guna2GradientButton13.Size = new System.Drawing.Size(86, 45);
            this.guna2GradientButton13.TabIndex = 17;
            this.guna2GradientButton13.Text = "Medium";
            this.guna2GradientButton13.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.guna2GradientButton13.TextOffset = new System.Drawing.Point(10, 0);
            this.guna2GradientButton13.UseTransparentBackground = true;
            // 
            // guna2GradientButton14
            // 
            this.guna2GradientButton14.Animated = true;
            this.guna2GradientButton14.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton14.CheckedState.Parent = this.guna2GradientButton14;
            this.guna2GradientButton14.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("guna2GradientButton14.CustomImages.Image")));
            this.guna2GradientButton14.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2GradientButton14.CustomImages.Parent = this.guna2GradientButton14;
            this.guna2GradientButton14.FillColor = System.Drawing.Color.Empty;
            this.guna2GradientButton14.FillColor2 = System.Drawing.Color.Empty;
            this.guna2GradientButton14.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton14.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton14.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.guna2GradientButton14.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.guna2GradientButton14.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton14.HoverState.Parent = this.guna2GradientButton14;
            this.guna2GradientButton14.Location = new System.Drawing.Point(222, 403);
            this.guna2GradientButton14.Name = "guna2GradientButton14";
            this.guna2GradientButton14.ShadowDecoration.Parent = this.guna2GradientButton14;
            this.guna2GradientButton14.Size = new System.Drawing.Size(105, 45);
            this.guna2GradientButton14.TabIndex = 16;
            this.guna2GradientButton14.Text = "Large";
            this.guna2GradientButton14.UseTransparentBackground = true;
            // 
            // panel11
            // 
            this.panel11.BackgroundImage = global::user_interface.Properties.Resources.istockphoto_173245886_612x612;
            this.panel11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.panel11.Controls.Add(this.guna2CustomGradientPanel4);
            this.panel11.Location = new System.Drawing.Point(15, 12);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(300, 358);
            this.panel11.TabIndex = 0;
            // 
            // guna2CustomGradientPanel4
            // 
            this.guna2CustomGradientPanel4.BackColor = System.Drawing.Color.Transparent;
            this.guna2CustomGradientPanel4.Controls.Add(this.label36);
            this.guna2CustomGradientPanel4.Controls.Add(this.label37);
            this.guna2CustomGradientPanel4.Controls.Add(this.label38);
            this.guna2CustomGradientPanel4.Controls.Add(this.pictureBox7);
            this.guna2CustomGradientPanel4.Controls.Add(this.pictureBox8);
            this.guna2CustomGradientPanel4.Controls.Add(this.label39);
            this.guna2CustomGradientPanel4.Controls.Add(this.label40);
            this.guna2CustomGradientPanel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.guna2CustomGradientPanel4.FillColor = System.Drawing.Color.Transparent;
            this.guna2CustomGradientPanel4.FillColor2 = System.Drawing.Color.Transparent;
            this.guna2CustomGradientPanel4.FillColor3 = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.guna2CustomGradientPanel4.FillColor4 = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(140)))), ((int)(((byte)(52)))));
            this.guna2CustomGradientPanel4.Location = new System.Drawing.Point(0, 252);
            this.guna2CustomGradientPanel4.Name = "guna2CustomGradientPanel4";
            this.guna2CustomGradientPanel4.ShadowDecoration.Parent = this.guna2CustomGradientPanel4;
            this.guna2CustomGradientPanel4.Size = new System.Drawing.Size(300, 106);
            this.guna2CustomGradientPanel4.TabIndex = 9;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label36.ForeColor = System.Drawing.Color.White;
            this.label36.Location = new System.Drawing.Point(192, 87);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(101, 15);
            this.label36.TabIndex = 22;
            this.label36.Text = "Medium Roasted";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label37.ForeColor = System.Drawing.Color.White;
            this.label37.Location = new System.Drawing.Point(204, 72);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(44, 15);
            this.label37.TabIndex = 19;
            this.label37.Text = "coffee";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label38.ForeColor = System.Drawing.Color.White;
            this.label38.Location = new System.Drawing.Point(258, 72);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(31, 15);
            this.label38.TabIndex = 20;
            this.label38.Text = "milk";
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(249, 18);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(48, 48);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox7.TabIndex = 21;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox8.Image")));
            this.pictureBox8.Location = new System.Drawing.Point(195, 18);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(48, 48);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox8.TabIndex = 10;
            this.pictureBox8.TabStop = false;
            // 
            // label39
            // 
            this.label39.Font = new System.Drawing.Font("Segoe UI", 15F);
            this.label39.ForeColor = System.Drawing.Color.White;
            this.label39.Location = new System.Drawing.Point(19, 58);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(139, 29);
            this.label39.TabIndex = 20;
            this.label39.Text = "With Oat Milk";
            // 
            // label40
            // 
            this.label40.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.label40.ForeColor = System.Drawing.Color.White;
            this.label40.Location = new System.Drawing.Point(19, 18);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(184, 40);
            this.label40.TabIndex = 19;
            this.label40.Text = "Cappuccino";
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.label41);
            this.panel12.Controls.Add(this.guna2GradientButton15);
            this.panel12.Controls.Add(this.guna2Separator7);
            this.panel12.Controls.Add(this.label42);
            this.panel12.Controls.Add(this.label43);
            this.panel12.Controls.Add(this.guna2GradientButton16);
            this.panel12.Controls.Add(this.guna2GradientButton17);
            this.panel12.Controls.Add(this.panel13);
            this.panel12.Location = new System.Drawing.Point(3, 1107);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(334, 546);
            this.panel12.TabIndex = 26;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.label41.ForeColor = System.Drawing.Color.White;
            this.label41.Location = new System.Drawing.Point(46, 503);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(52, 19);
            this.label41.TabIndex = 22;
            this.label41.Text = "Rs 200";
            // 
            // guna2GradientButton15
            // 
            this.guna2GradientButton15.Animated = true;
            this.guna2GradientButton15.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton15.CheckedState.Parent = this.guna2GradientButton15;
            this.guna2GradientButton15.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("guna2GradientButton15.CustomImages.Image")));
            this.guna2GradientButton15.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2GradientButton15.CustomImages.Parent = this.guna2GradientButton15;
            this.guna2GradientButton15.FillColor = System.Drawing.Color.Empty;
            this.guna2GradientButton15.FillColor2 = System.Drawing.Color.Empty;
            this.guna2GradientButton15.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton15.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton15.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.guna2GradientButton15.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.guna2GradientButton15.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton15.HoverState.Parent = this.guna2GradientButton15;
            this.guna2GradientButton15.Location = new System.Drawing.Point(154, 470);
            this.guna2GradientButton15.Name = "guna2GradientButton15";
            this.guna2GradientButton15.ShadowDecoration.Parent = this.guna2GradientButton15;
            this.guna2GradientButton15.Size = new System.Drawing.Size(141, 52);
            this.guna2GradientButton15.TabIndex = 21;
            this.guna2GradientButton15.Text = "Medium";
            this.guna2GradientButton15.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.guna2GradientButton15.TextOffset = new System.Drawing.Point(10, 0);
            this.guna2GradientButton15.UseTransparentBackground = true;
            // 
            // guna2Separator7
            // 
            this.guna2Separator7.Location = new System.Drawing.Point(26, 454);
            this.guna2Separator7.Name = "guna2Separator7";
            this.guna2Separator7.Size = new System.Drawing.Size(286, 10);
            this.guna2Separator7.TabIndex = 20;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.label42.ForeColor = System.Drawing.Color.White;
            this.label42.Location = new System.Drawing.Point(32, 461);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(81, 37);
            this.label42.TabIndex = 19;
            this.label42.Text = "Price";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label43.ForeColor = System.Drawing.Color.White;
            this.label43.Location = new System.Drawing.Point(47, 417);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(28, 15);
            this.label43.TabIndex = 18;
            this.label43.Text = "size";
            // 
            // guna2GradientButton16
            // 
            this.guna2GradientButton16.Animated = true;
            this.guna2GradientButton16.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton16.CheckedState.Parent = this.guna2GradientButton16;
            this.guna2GradientButton16.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("guna2GradientButton16.CustomImages.Image")));
            this.guna2GradientButton16.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2GradientButton16.CustomImages.Parent = this.guna2GradientButton16;
            this.guna2GradientButton16.FillColor = System.Drawing.Color.Empty;
            this.guna2GradientButton16.FillColor2 = System.Drawing.Color.Empty;
            this.guna2GradientButton16.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton16.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton16.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.guna2GradientButton16.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.guna2GradientButton16.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton16.HoverState.Parent = this.guna2GradientButton16;
            this.guna2GradientButton16.Location = new System.Drawing.Point(135, 403);
            this.guna2GradientButton16.Name = "guna2GradientButton16";
            this.guna2GradientButton16.ShadowDecoration.Parent = this.guna2GradientButton16;
            this.guna2GradientButton16.Size = new System.Drawing.Size(86, 45);
            this.guna2GradientButton16.TabIndex = 17;
            this.guna2GradientButton16.Text = "Medium";
            this.guna2GradientButton16.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.guna2GradientButton16.TextOffset = new System.Drawing.Point(10, 0);
            this.guna2GradientButton16.UseTransparentBackground = true;
            // 
            // guna2GradientButton17
            // 
            this.guna2GradientButton17.Animated = true;
            this.guna2GradientButton17.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton17.CheckedState.Parent = this.guna2GradientButton17;
            this.guna2GradientButton17.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("guna2GradientButton17.CustomImages.Image")));
            this.guna2GradientButton17.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2GradientButton17.CustomImages.Parent = this.guna2GradientButton17;
            this.guna2GradientButton17.FillColor = System.Drawing.Color.Empty;
            this.guna2GradientButton17.FillColor2 = System.Drawing.Color.Empty;
            this.guna2GradientButton17.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton17.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton17.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.guna2GradientButton17.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.guna2GradientButton17.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton17.HoverState.Parent = this.guna2GradientButton17;
            this.guna2GradientButton17.Location = new System.Drawing.Point(222, 403);
            this.guna2GradientButton17.Name = "guna2GradientButton17";
            this.guna2GradientButton17.ShadowDecoration.Parent = this.guna2GradientButton17;
            this.guna2GradientButton17.Size = new System.Drawing.Size(105, 45);
            this.guna2GradientButton17.TabIndex = 16;
            this.guna2GradientButton17.Text = "Large";
            this.guna2GradientButton17.UseTransparentBackground = true;
            // 
            // panel13
            // 
            this.panel13.BackgroundImage = global::user_interface.Properties.Resources.istockphoto_173245886_612x612;
            this.panel13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.panel13.Controls.Add(this.guna2CustomGradientPanel5);
            this.panel13.Location = new System.Drawing.Point(15, 12);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(300, 358);
            this.panel13.TabIndex = 0;
            // 
            // guna2CustomGradientPanel5
            // 
            this.guna2CustomGradientPanel5.BackColor = System.Drawing.Color.Transparent;
            this.guna2CustomGradientPanel5.Controls.Add(this.label44);
            this.guna2CustomGradientPanel5.Controls.Add(this.label45);
            this.guna2CustomGradientPanel5.Controls.Add(this.label46);
            this.guna2CustomGradientPanel5.Controls.Add(this.pictureBox9);
            this.guna2CustomGradientPanel5.Controls.Add(this.pictureBox10);
            this.guna2CustomGradientPanel5.Controls.Add(this.label47);
            this.guna2CustomGradientPanel5.Controls.Add(this.label48);
            this.guna2CustomGradientPanel5.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.guna2CustomGradientPanel5.FillColor = System.Drawing.Color.Transparent;
            this.guna2CustomGradientPanel5.FillColor2 = System.Drawing.Color.Transparent;
            this.guna2CustomGradientPanel5.FillColor3 = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.guna2CustomGradientPanel5.FillColor4 = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(140)))), ((int)(((byte)(52)))));
            this.guna2CustomGradientPanel5.Location = new System.Drawing.Point(0, 252);
            this.guna2CustomGradientPanel5.Name = "guna2CustomGradientPanel5";
            this.guna2CustomGradientPanel5.ShadowDecoration.Parent = this.guna2CustomGradientPanel5;
            this.guna2CustomGradientPanel5.Size = new System.Drawing.Size(300, 106);
            this.guna2CustomGradientPanel5.TabIndex = 9;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label44.ForeColor = System.Drawing.Color.White;
            this.label44.Location = new System.Drawing.Point(192, 87);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(101, 15);
            this.label44.TabIndex = 22;
            this.label44.Text = "Medium Roasted";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label45.ForeColor = System.Drawing.Color.White;
            this.label45.Location = new System.Drawing.Point(204, 72);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(44, 15);
            this.label45.TabIndex = 19;
            this.label45.Text = "coffee";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label46.ForeColor = System.Drawing.Color.White;
            this.label46.Location = new System.Drawing.Point(258, 72);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(31, 15);
            this.label46.TabIndex = 20;
            this.label46.Text = "milk";
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox9.Image")));
            this.pictureBox9.Location = new System.Drawing.Point(249, 18);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(48, 48);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox9.TabIndex = 21;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox10.Image")));
            this.pictureBox10.Location = new System.Drawing.Point(195, 18);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(48, 48);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox10.TabIndex = 10;
            this.pictureBox10.TabStop = false;
            // 
            // label47
            // 
            this.label47.Font = new System.Drawing.Font("Segoe UI", 15F);
            this.label47.ForeColor = System.Drawing.Color.White;
            this.label47.Location = new System.Drawing.Point(19, 58);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(139, 29);
            this.label47.TabIndex = 20;
            this.label47.Text = "With Oat Milk";
            // 
            // label48
            // 
            this.label48.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.label48.ForeColor = System.Drawing.Color.White;
            this.label48.Location = new System.Drawing.Point(19, 18);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(184, 40);
            this.label48.TabIndex = 19;
            this.label48.Text = "Cappuccino";
            // 
            // panel16
            // 
            this.panel16.Controls.Add(this.label57);
            this.panel16.Controls.Add(this.guna2GradientButton21);
            this.panel16.Controls.Add(this.guna2Separator9);
            this.panel16.Controls.Add(this.label58);
            this.panel16.Controls.Add(this.label59);
            this.panel16.Controls.Add(this.guna2GradientButton22);
            this.panel16.Controls.Add(this.guna2GradientButton23);
            this.panel16.Controls.Add(this.panel17);
            this.panel16.Location = new System.Drawing.Point(343, 1107);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(334, 546);
            this.panel16.TabIndex = 27;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.label57.ForeColor = System.Drawing.Color.White;
            this.label57.Location = new System.Drawing.Point(46, 503);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(52, 19);
            this.label57.TabIndex = 22;
            this.label57.Text = "Rs 200";
            // 
            // guna2GradientButton21
            // 
            this.guna2GradientButton21.Animated = true;
            this.guna2GradientButton21.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton21.CheckedState.Parent = this.guna2GradientButton21;
            this.guna2GradientButton21.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("guna2GradientButton21.CustomImages.Image")));
            this.guna2GradientButton21.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2GradientButton21.CustomImages.Parent = this.guna2GradientButton21;
            this.guna2GradientButton21.FillColor = System.Drawing.Color.Empty;
            this.guna2GradientButton21.FillColor2 = System.Drawing.Color.Empty;
            this.guna2GradientButton21.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton21.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton21.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.guna2GradientButton21.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.guna2GradientButton21.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton21.HoverState.Parent = this.guna2GradientButton21;
            this.guna2GradientButton21.Location = new System.Drawing.Point(154, 470);
            this.guna2GradientButton21.Name = "guna2GradientButton21";
            this.guna2GradientButton21.ShadowDecoration.Parent = this.guna2GradientButton21;
            this.guna2GradientButton21.Size = new System.Drawing.Size(141, 52);
            this.guna2GradientButton21.TabIndex = 21;
            this.guna2GradientButton21.Text = "Medium";
            this.guna2GradientButton21.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.guna2GradientButton21.TextOffset = new System.Drawing.Point(10, 0);
            this.guna2GradientButton21.UseTransparentBackground = true;
            // 
            // guna2Separator9
            // 
            this.guna2Separator9.Location = new System.Drawing.Point(26, 454);
            this.guna2Separator9.Name = "guna2Separator9";
            this.guna2Separator9.Size = new System.Drawing.Size(286, 10);
            this.guna2Separator9.TabIndex = 20;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.label58.ForeColor = System.Drawing.Color.White;
            this.label58.Location = new System.Drawing.Point(32, 461);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(81, 37);
            this.label58.TabIndex = 19;
            this.label58.Text = "Price";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label59.ForeColor = System.Drawing.Color.White;
            this.label59.Location = new System.Drawing.Point(47, 417);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(28, 15);
            this.label59.TabIndex = 18;
            this.label59.Text = "size";
            // 
            // guna2GradientButton22
            // 
            this.guna2GradientButton22.Animated = true;
            this.guna2GradientButton22.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton22.CheckedState.Parent = this.guna2GradientButton22;
            this.guna2GradientButton22.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("guna2GradientButton22.CustomImages.Image")));
            this.guna2GradientButton22.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2GradientButton22.CustomImages.Parent = this.guna2GradientButton22;
            this.guna2GradientButton22.FillColor = System.Drawing.Color.Empty;
            this.guna2GradientButton22.FillColor2 = System.Drawing.Color.Empty;
            this.guna2GradientButton22.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton22.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton22.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.guna2GradientButton22.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.guna2GradientButton22.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton22.HoverState.Parent = this.guna2GradientButton22;
            this.guna2GradientButton22.Location = new System.Drawing.Point(135, 403);
            this.guna2GradientButton22.Name = "guna2GradientButton22";
            this.guna2GradientButton22.ShadowDecoration.Parent = this.guna2GradientButton22;
            this.guna2GradientButton22.Size = new System.Drawing.Size(86, 45);
            this.guna2GradientButton22.TabIndex = 17;
            this.guna2GradientButton22.Text = "Medium";
            this.guna2GradientButton22.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.guna2GradientButton22.TextOffset = new System.Drawing.Point(10, 0);
            this.guna2GradientButton22.UseTransparentBackground = true;
            // 
            // guna2GradientButton23
            // 
            this.guna2GradientButton23.Animated = true;
            this.guna2GradientButton23.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton23.CheckedState.Parent = this.guna2GradientButton23;
            this.guna2GradientButton23.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("guna2GradientButton23.CustomImages.Image")));
            this.guna2GradientButton23.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2GradientButton23.CustomImages.Parent = this.guna2GradientButton23;
            this.guna2GradientButton23.FillColor = System.Drawing.Color.Empty;
            this.guna2GradientButton23.FillColor2 = System.Drawing.Color.Empty;
            this.guna2GradientButton23.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton23.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton23.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.guna2GradientButton23.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.guna2GradientButton23.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton23.HoverState.Parent = this.guna2GradientButton23;
            this.guna2GradientButton23.Location = new System.Drawing.Point(222, 403);
            this.guna2GradientButton23.Name = "guna2GradientButton23";
            this.guna2GradientButton23.ShadowDecoration.Parent = this.guna2GradientButton23;
            this.guna2GradientButton23.Size = new System.Drawing.Size(105, 45);
            this.guna2GradientButton23.TabIndex = 16;
            this.guna2GradientButton23.Text = "Large";
            this.guna2GradientButton23.UseTransparentBackground = true;
            // 
            // panel17
            // 
            this.panel17.BackgroundImage = global::user_interface.Properties.Resources.istockphoto_173245886_612x612;
            this.panel17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.panel17.Controls.Add(this.guna2CustomGradientPanel7);
            this.panel17.Location = new System.Drawing.Point(15, 12);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(300, 358);
            this.panel17.TabIndex = 0;
            // 
            // guna2CustomGradientPanel7
            // 
            this.guna2CustomGradientPanel7.BackColor = System.Drawing.Color.Transparent;
            this.guna2CustomGradientPanel7.Controls.Add(this.label60);
            this.guna2CustomGradientPanel7.Controls.Add(this.label61);
            this.guna2CustomGradientPanel7.Controls.Add(this.label62);
            this.guna2CustomGradientPanel7.Controls.Add(this.pictureBox13);
            this.guna2CustomGradientPanel7.Controls.Add(this.pictureBox14);
            this.guna2CustomGradientPanel7.Controls.Add(this.label63);
            this.guna2CustomGradientPanel7.Controls.Add(this.label64);
            this.guna2CustomGradientPanel7.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.guna2CustomGradientPanel7.FillColor = System.Drawing.Color.Transparent;
            this.guna2CustomGradientPanel7.FillColor2 = System.Drawing.Color.Transparent;
            this.guna2CustomGradientPanel7.FillColor3 = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.guna2CustomGradientPanel7.FillColor4 = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(140)))), ((int)(((byte)(52)))));
            this.guna2CustomGradientPanel7.Location = new System.Drawing.Point(0, 252);
            this.guna2CustomGradientPanel7.Name = "guna2CustomGradientPanel7";
            this.guna2CustomGradientPanel7.ShadowDecoration.Parent = this.guna2CustomGradientPanel7;
            this.guna2CustomGradientPanel7.Size = new System.Drawing.Size(300, 106);
            this.guna2CustomGradientPanel7.TabIndex = 9;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label60.ForeColor = System.Drawing.Color.White;
            this.label60.Location = new System.Drawing.Point(192, 87);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(101, 15);
            this.label60.TabIndex = 22;
            this.label60.Text = "Medium Roasted";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label61.ForeColor = System.Drawing.Color.White;
            this.label61.Location = new System.Drawing.Point(204, 72);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(44, 15);
            this.label61.TabIndex = 19;
            this.label61.Text = "coffee";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label62.ForeColor = System.Drawing.Color.White;
            this.label62.Location = new System.Drawing.Point(258, 72);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(31, 15);
            this.label62.TabIndex = 20;
            this.label62.Text = "milk";
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox13.Image")));
            this.pictureBox13.Location = new System.Drawing.Point(249, 18);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(48, 48);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox13.TabIndex = 21;
            this.pictureBox13.TabStop = false;
            // 
            // pictureBox14
            // 
            this.pictureBox14.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox14.Image")));
            this.pictureBox14.Location = new System.Drawing.Point(195, 18);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(48, 48);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox14.TabIndex = 10;
            this.pictureBox14.TabStop = false;
            // 
            // label63
            // 
            this.label63.Font = new System.Drawing.Font("Segoe UI", 15F);
            this.label63.ForeColor = System.Drawing.Color.White;
            this.label63.Location = new System.Drawing.Point(19, 58);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(139, 29);
            this.label63.TabIndex = 20;
            this.label63.Text = "With Oat Milk";
            // 
            // label64
            // 
            this.label64.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.label64.ForeColor = System.Drawing.Color.White;
            this.label64.Location = new System.Drawing.Point(19, 18);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(184, 40);
            this.label64.TabIndex = 19;
            this.label64.Text = "Cappuccino";
            // 
            // panel14
            // 
            this.panel14.Controls.Add(this.label49);
            this.panel14.Controls.Add(this.guna2GradientButton18);
            this.panel14.Controls.Add(this.guna2Separator8);
            this.panel14.Controls.Add(this.label51);
            this.panel14.Controls.Add(this.guna2GradientButton19);
            this.panel14.Controls.Add(this.guna2GradientButton20);
            this.panel14.Controls.Add(this.panel15);
            this.panel14.Location = new System.Drawing.Point(3, 1659);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(334, 546);
            this.panel14.TabIndex = 27;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.label49.ForeColor = System.Drawing.Color.White;
            this.label49.Location = new System.Drawing.Point(46, 503);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(52, 19);
            this.label49.TabIndex = 22;
            this.label49.Text = "Rs 200";
            // 
            // guna2GradientButton18
            // 
            this.guna2GradientButton18.Animated = true;
            this.guna2GradientButton18.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton18.CheckedState.Parent = this.guna2GradientButton18;
            this.guna2GradientButton18.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("guna2GradientButton18.CustomImages.Image")));
            this.guna2GradientButton18.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2GradientButton18.CustomImages.Parent = this.guna2GradientButton18;
            this.guna2GradientButton18.FillColor = System.Drawing.Color.Empty;
            this.guna2GradientButton18.FillColor2 = System.Drawing.Color.Empty;
            this.guna2GradientButton18.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton18.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton18.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.guna2GradientButton18.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.guna2GradientButton18.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton18.HoverState.Parent = this.guna2GradientButton18;
            this.guna2GradientButton18.Location = new System.Drawing.Point(154, 470);
            this.guna2GradientButton18.Name = "guna2GradientButton18";
            this.guna2GradientButton18.ShadowDecoration.Parent = this.guna2GradientButton18;
            this.guna2GradientButton18.Size = new System.Drawing.Size(141, 52);
            this.guna2GradientButton18.TabIndex = 21;
            this.guna2GradientButton18.Text = "Medium";
            this.guna2GradientButton18.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.guna2GradientButton18.TextOffset = new System.Drawing.Point(10, 0);
            this.guna2GradientButton18.UseTransparentBackground = true;
            // 
            // guna2Separator8
            // 
            this.guna2Separator8.Location = new System.Drawing.Point(26, 454);
            this.guna2Separator8.Name = "guna2Separator8";
            this.guna2Separator8.Size = new System.Drawing.Size(286, 10);
            this.guna2Separator8.TabIndex = 20;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label51.ForeColor = System.Drawing.Color.White;
            this.label51.Location = new System.Drawing.Point(47, 417);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(28, 15);
            this.label51.TabIndex = 18;
            this.label51.Text = "size";
            // 
            // guna2GradientButton19
            // 
            this.guna2GradientButton19.Animated = true;
            this.guna2GradientButton19.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton19.CheckedState.Parent = this.guna2GradientButton19;
            this.guna2GradientButton19.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("guna2GradientButton19.CustomImages.Image")));
            this.guna2GradientButton19.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2GradientButton19.CustomImages.Parent = this.guna2GradientButton19;
            this.guna2GradientButton19.FillColor = System.Drawing.Color.Empty;
            this.guna2GradientButton19.FillColor2 = System.Drawing.Color.Empty;
            this.guna2GradientButton19.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton19.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton19.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.guna2GradientButton19.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.guna2GradientButton19.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton19.HoverState.Parent = this.guna2GradientButton19;
            this.guna2GradientButton19.Location = new System.Drawing.Point(135, 403);
            this.guna2GradientButton19.Name = "guna2GradientButton19";
            this.guna2GradientButton19.ShadowDecoration.Parent = this.guna2GradientButton19;
            this.guna2GradientButton19.Size = new System.Drawing.Size(86, 45);
            this.guna2GradientButton19.TabIndex = 17;
            this.guna2GradientButton19.Text = "Medium";
            this.guna2GradientButton19.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.guna2GradientButton19.TextOffset = new System.Drawing.Point(10, 0);
            this.guna2GradientButton19.UseTransparentBackground = true;
            // 
            // guna2GradientButton20
            // 
            this.guna2GradientButton20.Animated = true;
            this.guna2GradientButton20.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton20.CheckedState.Parent = this.guna2GradientButton20;
            this.guna2GradientButton20.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("guna2GradientButton20.CustomImages.Image")));
            this.guna2GradientButton20.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2GradientButton20.CustomImages.Parent = this.guna2GradientButton20;
            this.guna2GradientButton20.FillColor = System.Drawing.Color.Empty;
            this.guna2GradientButton20.FillColor2 = System.Drawing.Color.Empty;
            this.guna2GradientButton20.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton20.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton20.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.guna2GradientButton20.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.guna2GradientButton20.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton20.HoverState.Parent = this.guna2GradientButton20;
            this.guna2GradientButton20.Location = new System.Drawing.Point(222, 403);
            this.guna2GradientButton20.Name = "guna2GradientButton20";
            this.guna2GradientButton20.ShadowDecoration.Parent = this.guna2GradientButton20;
            this.guna2GradientButton20.Size = new System.Drawing.Size(105, 45);
            this.guna2GradientButton20.TabIndex = 16;
            this.guna2GradientButton20.Text = "Large";
            this.guna2GradientButton20.UseTransparentBackground = true;
            // 
            // panel15
            // 
            this.panel15.BackgroundImage = global::user_interface.Properties.Resources.istockphoto_173245886_612x612;
            this.panel15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.panel15.Controls.Add(this.guna2CustomGradientPanel6);
            this.panel15.Location = new System.Drawing.Point(15, 12);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(300, 358);
            this.panel15.TabIndex = 0;
            // 
            // guna2CustomGradientPanel6
            // 
            this.guna2CustomGradientPanel6.BackColor = System.Drawing.Color.Transparent;
            this.guna2CustomGradientPanel6.Controls.Add(this.label52);
            this.guna2CustomGradientPanel6.Controls.Add(this.label53);
            this.guna2CustomGradientPanel6.Controls.Add(this.label54);
            this.guna2CustomGradientPanel6.Controls.Add(this.pictureBox11);
            this.guna2CustomGradientPanel6.Controls.Add(this.pictureBox12);
            this.guna2CustomGradientPanel6.Controls.Add(this.label55);
            this.guna2CustomGradientPanel6.Controls.Add(this.label56);
            this.guna2CustomGradientPanel6.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.guna2CustomGradientPanel6.FillColor = System.Drawing.Color.Transparent;
            this.guna2CustomGradientPanel6.FillColor2 = System.Drawing.Color.Transparent;
            this.guna2CustomGradientPanel6.FillColor3 = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.guna2CustomGradientPanel6.FillColor4 = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(140)))), ((int)(((byte)(52)))));
            this.guna2CustomGradientPanel6.Location = new System.Drawing.Point(0, 252);
            this.guna2CustomGradientPanel6.Name = "guna2CustomGradientPanel6";
            this.guna2CustomGradientPanel6.ShadowDecoration.Parent = this.guna2CustomGradientPanel6;
            this.guna2CustomGradientPanel6.Size = new System.Drawing.Size(300, 106);
            this.guna2CustomGradientPanel6.TabIndex = 9;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label52.ForeColor = System.Drawing.Color.White;
            this.label52.Location = new System.Drawing.Point(192, 87);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(101, 15);
            this.label52.TabIndex = 22;
            this.label52.Text = "Medium Roasted";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label53.ForeColor = System.Drawing.Color.White;
            this.label53.Location = new System.Drawing.Point(204, 72);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(44, 15);
            this.label53.TabIndex = 19;
            this.label53.Text = "coffee";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label54.ForeColor = System.Drawing.Color.White;
            this.label54.Location = new System.Drawing.Point(258, 72);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(31, 15);
            this.label54.TabIndex = 20;
            this.label54.Text = "milk";
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox11.Image")));
            this.pictureBox11.Location = new System.Drawing.Point(249, 18);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(48, 48);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox11.TabIndex = 21;
            this.pictureBox11.TabStop = false;
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox12.Image")));
            this.pictureBox12.Location = new System.Drawing.Point(195, 18);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(48, 48);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox12.TabIndex = 10;
            this.pictureBox12.TabStop = false;
            // 
            // label55
            // 
            this.label55.Font = new System.Drawing.Font("Segoe UI", 15F);
            this.label55.ForeColor = System.Drawing.Color.White;
            this.label55.Location = new System.Drawing.Point(19, 58);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(139, 29);
            this.label55.TabIndex = 20;
            this.label55.Text = "With Oat Milk";
            // 
            // label56
            // 
            this.label56.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.label56.ForeColor = System.Drawing.Color.White;
            this.label56.Location = new System.Drawing.Point(19, 18);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(184, 40);
            this.label56.TabIndex = 19;
            this.label56.Text = "Cappuccino";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.savouriespanel.SetFlowBreak(this.label50, true);
            this.label50.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.label50.ForeColor = System.Drawing.Color.White;
            this.label50.Location = new System.Drawing.Point(343, 1656);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(81, 37);
            this.label50.TabIndex = 19;
            this.label50.Text = "Price";
            // 
            // savouries
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.savouriespanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "savouries";
            this.Text = "savouries";
            this.savouriespanel.ResumeLayout(false);
            this.savouriespanel.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.Cappuccino_panel.ResumeLayout(false);
            this.tital_panal_cappuccino.ResumeLayout(false);
            this.tital_panal_cappuccino.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.guna2CustomGradientPanel2.ResumeLayout(false);
            this.guna2CustomGradientPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.guna2CustomGradientPanel3.ResumeLayout(false);
            this.guna2CustomGradientPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.guna2CustomGradientPanel4.ResumeLayout(false);
            this.guna2CustomGradientPanel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.guna2CustomGradientPanel5.ResumeLayout(false);
            this.guna2CustomGradientPanel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.panel17.ResumeLayout(false);
            this.guna2CustomGradientPanel7.ResumeLayout(false);
            this.guna2CustomGradientPanel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.guna2CustomGradientPanel6.ResumeLayout(false);
            this.guna2CustomGradientPanel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel savouriespanel;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label17;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton5;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator3;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton4;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton3;
        private System.Windows.Forms.Panel Cappuccino_panel;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel tital_panal_cappuccino;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label8;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton6;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator4;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton7;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton8;
        private System.Windows.Forms.Panel panel7;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel guna2CustomGradientPanel2;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label25;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton9;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator5;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton10;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton11;
        private System.Windows.Forms.Panel panel9;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel guna2CustomGradientPanel3;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label33;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton12;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator6;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton13;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton14;
        private System.Windows.Forms.Panel panel11;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel guna2CustomGradientPanel4;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label label41;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton15;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator7;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton16;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton17;
        private System.Windows.Forms.Panel panel13;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel guna2CustomGradientPanel5;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Label label57;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton21;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator9;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton22;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton23;
        private System.Windows.Forms.Panel panel17;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel guna2CustomGradientPanel7;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Label label49;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton18;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator8;
        private System.Windows.Forms.Label label51;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton19;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton20;
        private System.Windows.Forms.Panel panel15;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel guna2CustomGradientPanel6;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label50;
    }
}